
public class StarRevesre {
public static void main(String[] args) {
	
	
//	*****
//	****
//	***
//	**
//	*
	for(int rows =4;rows>=0;rows--) {
		for(int cols=0;cols<=rows;cols++) {
			System.out.print("*");
		}
		System.out.println();
	}
}
}
