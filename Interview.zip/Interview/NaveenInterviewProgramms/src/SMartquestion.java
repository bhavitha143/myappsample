
public class SMartquestion {
public static void main(String[] args) {
	
	
	
	
	// Integer caching 
	// it will give true when you have to give range   -128 to 127  otherwise false
	
	Integer num1=127;
	Integer num2=127;
	
	if(num1==num2) {
		System.out.println("both are equal");
	}
	else {
		System.out.println("both are not equal");
	}
}
}
