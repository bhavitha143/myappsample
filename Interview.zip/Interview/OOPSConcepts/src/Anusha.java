
public class Anusha {

	int add(int x, int y) {
		 int c= x + y;
		 return c;

	}

	public static void main(String[] args) {
		Anusha anu = new Anusha();
		anu.add(10,20);
		System.out.println(anu);

	}
}
