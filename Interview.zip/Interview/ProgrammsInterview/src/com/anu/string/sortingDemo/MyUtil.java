package com.anu.string.sortingDemo;

import java.util.ArrayList;

public class MyUtil {

	
public 	static<T> void iterateList(ArrayList<T> intlist) {
		for (T temp : intlist) {

			System.out.println(temp);
		}
	}
}
