
public class Increment {
	
	
	 public static void main(String[] args) {
		 int x=10;
		 System.out.println(x++);
		 System.out.println(x++);//10 (11)
		 System.out.println(x);
		 System.out.println(++x);//12  
		 System.out.println(x--);//12 (11)  
		 System.out.println(--x);//10  
	}
		
	

}
