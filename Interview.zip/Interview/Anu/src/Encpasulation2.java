
public class Encpasulation2 {
	public static void main(String[] args) {
		Encapsulation ed=new Encapsulation();
		ed.setName("anusha");
		System.out.println(ed.getName());
		
	}

}
