	
	class Anu {
		void m1() throws ArrayIndexOutOfBoundsException {
			System.out.println("i am parent");
		}
	}
		class B extends Anu {
			void m2() throws IndexOutOfBoundsException {
				System.out.println("i am b");
			}
		}
	
	
	
	public class Anjana {
		public static void main(String[] args) {
			Anu b=new B();
		((B) b).m2();	
		}
	
	}
