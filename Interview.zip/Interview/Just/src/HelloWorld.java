
public class HelloWorld {

	public static void main(String[] args) {
	       int i=2,num=5;
	       int count=0;
	      while(num%i==0){ 
	           count++;
	       }
	         if(count==0) {
	        	 System.out.println(num + " is a   prime number."); 
	         }
	         else {
	        	 System.out.println(num + " is a  not prime number.");
	         }
	      }
	
}
