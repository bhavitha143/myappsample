public class Compare {
public static void main(String[] args) {
	
	/*
	 * String s="anusha"; //String a="anusha"; String b= new String("anusha");
	 * System.out.println("anusha"+ new ArrayList(1));
	 * System.out.println(s.equals(b));
	 */
	
	String let="";
	while(let.length()<2) {
		let+="a";
		System.out.println(let);
	}
}
}
