import java.util.Scanner;

public class PrintingName {
public static void main(String[] args) {
	
	
	Scanner sc = new Scanner(System.in);
	System.out.println("enter name");
	String name = sc.next();
	System.out.println("hello good morning "+ " "+ name);
	
}
}
