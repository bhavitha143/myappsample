package com.collection.anu;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class HashMapDemo {
	
	public static void main(String[] args) {
		
		HashMap<String,Integer> hm =new HashMap<>();
		
		hm.put("anusha", 90);
		hm.put("anil", 70);
		hm.put("anjani", 80);
		hm.put("arun", 60);
		hm.put("aji", 50);
		hm.put("anusha", 200);
		
		for(Entry<String, Integer> entry: hm.entrySet()) {
			System.out.println(entry.getKey() + entry .getValue());
			
		}
		
	}
	

}
