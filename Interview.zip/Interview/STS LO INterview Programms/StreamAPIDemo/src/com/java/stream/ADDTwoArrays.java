package com.java.stream;

public class ADDTwoArrays {
	public static void main(String[] args) {
		
		
		int a[]= {1,2,3},b[]= {4,5,6};
		
		int sum=0,sum1=0,total=0;
		for(int i=0;i<a.length;i++) {
			sum=a[i];
		}
			for(int j=0;j<b.length;j++) {
				sum1=b[j];
			}
			total=sum+sum1;
			System.out.print(total);
			}
			
			
		
	}


