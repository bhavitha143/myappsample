package com.java.stream;

import java.util.Arrays;

public class SortAnArray {

	
	public static void main(String[] args) {
		
		int a[]= {1,3,2,4,5};
		
		Arrays.sort(a);
		System.out.println(Arrays.toString(a));
		
		
	}
}
