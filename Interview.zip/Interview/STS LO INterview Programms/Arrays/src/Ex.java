
public class Ex {

	/*
	 * public String name;
	 * 
	 * void print(String name) { this.name = name; System.out.println(name); }
	 */

	public static void main(String[] args) {

		
		String str="    anusha  kolli!@##$$$$  ";
		str =str.replaceAll("[^0-9a-zA-Z]", "");
		String str2 =str.replaceAll("\\s", "");
	//str=str.trim();
	System.out.println(str);
	System.out.println(str2);
		
		
	/*
	 * Object a=null; System.out.println(a.toString());
	 */
		/*
		 * int arr[] = null; // array is assigned a null value Sy
		 * stem.out.println("The length of the array arr is: " + arr.length);
		 */ 
	    }  
	
	
	

}
